# Handoff: snip Landing Page

## Overview
Marketing landing page for **snip**, a free/open-source macOS menu-bar utility that strips tracking parameters (UTM tags, `fbclid`, `gclid`, etc.) from URLs automatically whenever they're copied. The page pitches the product, demonstrates it live with an animated fake "before/after" URL, lets the visitor paste their own real URL to try it, lists the parameters it recognizes, explains the 3-step flow, and drives downloads via GitHub (no App Store / paid tier — it's a free download).

## About the Design Files
The file in this bundle (`snip landing page.dc.html`) is a **design reference built in HTML** — a high-fidelity prototype of the intended look, motion, and interaction, not production code to copy verbatim. Implement this design in your target stack (plain HTML/CSS/JS static site, Next.js, Astro, etc. — whatever this marketing site already runs on, or the simplest static option if none exists) using this doc + the HTML file as the source of truth for exact values.

## Fidelity
**High-fidelity.** Colors, type, spacing, copy, and animation timing are final. Recreate pixel-for-pixel; don't reinterpret layout or restyle.

## Screens / Sections
Single scrolling page, six sections top to bottom:

### 1. Nav (sticky)
- Sticky top, `padding: 13px 40px`, translucent background `rgba(245,243,238,0.88)` + `backdrop-filter: blur(16px)`, bottom border `1px solid rgba(22,21,15,0.07)`, `z-index: 50`.
- Left: wordmark "snip." in DM Mono 500 15px, letter-spacing -0.3px, plus a pill badge "macOS" (DM Mono 10px, border `1px solid rgba(22,21,15,0.13)`, radius 99px, padding `2px 8px`).
- Right: "GitHub ↗" link, DM Sans 500 13px, opacity 0.55, links to `https://github.com/maferland/snip`.

### 2. Hero
- Wrapper has a radial gradient background: `radial-gradient(ellipse 90% 70% at 50% 0%, oklch(0.97 0.03 90) 0%, #F5F3EE 62%)`, `overflow: hidden`, `position: relative`.
- A full-bleed `<canvas>` sits absolutely positioned behind the content (see Animation → backgroundRain) — ambient falling tracking-param text at very low opacity, purely decorative.
- Eyebrow badge: "✂ macOS · Menu Bar · Free · Open Source", DM Mono 11px, uppercase, letter-spacing 0.09em, color `#9B9890`.
- H1: "Copy clean." — Instrument Serif italic, `clamp(68px,10.5vw,104px)`, line-height 0.95, letter-spacing -0.025em.
- Subhead: "Strips tracking parameters from every URL you copy. Silently. Automatically." DM Sans 300, 18px, color `#4C4840`, max-width 460px, centered.
- **Demo card** (white, radius 16px, border `1px solid rgba(22,21,15,0.09)`, shadow `0 4px 28px rgba(22,21,15,0.08), 0 1px 3px rgba(22,21,15,0.05)`, padding `22px 26px 24px`):
  - Chrome bar: 3 traffic-light dots (11px circles, decreasing opacity) + a scenario label (e.g. "from twitter.com", DM Mono 11px `#C8C6C2`) on the left; a green "✓ N stripped" badge fades in on the right once the current cycle finishes stripping (`white-space: nowrap` — must not wrap).
  - URL row: monospace 12px in a light gray inset box (`#F7F6F2`, radius 10px, min-height 52px, `white-space: nowrap; overflow: hidden`). See Animation section for the full loop behavior.
- CTAs: primary button "↓ Download on GitHub" (dark fill `#16150F`, text `#F5F3EE`, radius 9px, padding `12px 24px`) + secondary text link "View source ↗" (`#8B8880`).

### 3. Try It (dark section)
- Background `#111008`, padding `80px 40px`, content centered, max-width 620px.
- Eyebrow "Try it" (`#504E46`), H2 "Paste a dirty URL." (Instrument Serif italic, `clamp(36px,5vw,54px)`, white).
- Text input (full width, dark translucent fill `rgba(245,243,238,0.07)`, border `1px solid rgba(245,243,238,0.14)`, radius 10px, padding `14px 18px`, DM Mono 13px, placeholder `https://example.com?utm_source=twitter&fbclid=IwAR3x…`).
- On valid input with trackable params found → result panel appears below (`rgba(245,243,238,0.04)` bg, border `rgba(245,243,238,0.08)`, radius 10px, padding `18px 20px`):
  - "✓ CLEANED" label (green, uppercase, 11px).
  - Cleaned URL text + a **Copy** button inline to its right (ghost button, DM Mono 11px, label toggles to "✓ copied" in green for 1.8s after click, then reverts).
  - Row of struck-through orange chips listing exactly which params were removed, prefixed "stripped:".
- On valid input with **no** trackable params → a single green success banner: "✓ Already clean — no tracking params found".

### 4. What Gets Stripped
- Light section, padding `80px 40px`, max-width 900px, centered text.
- Eyebrow "What gets stripped", H2 "Every tracker, recognized."
- Wrapped row of pill chips (one per known param, see `trackingParams` list in tokens) — DM Mono 12px, subtle gray fill, hover state turns orange + strikes through the text to preview the "snip" action. Trailing "+ more" (non-interactive, muted).
- Caption: "Hover any param to preview snip doing its thing."

### 5. How It Works
- Off-white section `#FAF9F5`, bordered top/bottom, padding fluid via clamp, max-width 780px.
- Eyebrow "How it works", H2 "Three steps, then never again."
- 3-column grid (`repeat(auto-fit, minmax(220px,1fr))`, `gap: clamp(28px,6vw,40px)`) that collapses to a single column under ~460px. Each step is a horizontal row: a 40×40px rounded-square icon tile (white fill, `1px solid rgba(22,21,15,0.08)` border, radius 10px) holding the step glyph (↓ / ⌘C / ✓), followed by a text block (step number in muted mono, DM Sans 500 16px title, 14px/1.65 `#6A6760` description). This row layout keeps every step readable as a clean list on mobile instead of stacking glyph→title→paragraph vertically per step. Copy: **Install** (drag to /Applications, settles into menu bar) / **Copy any URL** (from browser, Slack, email — snip watches every copy event) / **Paste clean** (already stripped, no UTM noise).

### 6. Bottom CTA + Footer
- Centered, max-width 640px, padding `96px 40px 80px`. H2 "Start copying clean." (Instrument Serif italic, `clamp(44px,6.5vw,72px)`), supporting line "Free, open source, MIT licensed. Runs quietly on macOS, forever." Same primary button as hero.
- Footer: bordered top, `padding: 22px 40px`, flex space-between. Left: "snip. · MIT" (DM Mono 12px muted). Right: links to `maferland.com ↗` and `GitHub ↗` (same styling).

## Interactions & Behavior
See `design-tokens.json` → `animation` and `interactiveDemo` for exact timings and easing. Summary:
- **Autoplay hero demo**: loops through 3 canned dirty-URL scenarios. Params are highlighted (orange flash) and struck through **one at a time, right-to-left** (last query param goes first — mirrors how a human would trim a URL), each strip confirmed before moving to the next, then the whole URL turns green and a "✓ N stripped" badge appears. Holds ~3s, then cycles to the next scenario, forever.
- **Background canvas rain**: cosmetic only, low-opacity falling parameter names, continuous `requestAnimationFrame` loop, resizes with its container via `ResizeObserver`.
- **Live "Try it" input**: fully real — uses the actual `URL`/`URLSearchParams` API against the same tracking-param list as the marketing chips, not scripted.
- **Copy button**: `navigator.clipboard.writeText`, 1.8s "✓ copied" confirmation state.
- **Chip hover**: instant preview affordance on the "What gets stripped" chips (color/strike/bg transition, 0.15s).
- No client-side routing; all header/footer links are plain external anchors (`target="_blank"`) to GitHub and maferland.com.

## State Management
Minimal — this is a static marketing page. State needed if reimplementing the interactive parts:
- Hero demo: current scenario index, current param index being highlighted, list of already-stripped indices, phase (`dirty` / `snipping` / `clean`). Driven by a timer sequence, not user input.
- Try-it input: raw input string → derived cleaned URL + derived list of stripped params (pure function, recompute on change, no debounce needed).
- Copy button: boolean "just copied" flag with a 1.8s auto-reset timeout.

## Logo / Brand Mark
A rounded-square tile mark (dark fill, italic serif lowercase "s", struck through with a short orange bar — visually "part of the word snipped away") sits to the left of the "snip." wordmark in the nav. Full spec, clear-space, and file locations are in `design-tokens.json` → `logo`. Vector source, favicon/app-icon PNGs at 9 sizes, and light/dark wordmark lockups are bundled under `brand/`.

## Responsive Behavior
The page has no fixed breakpoints — spacing and type scale fluidly via `clamp()`, and a few rows (`hero CTAs`, `footer links`, the `try it` copy-button row) use `flex-wrap` to stack under narrow widths. Details and exact clamp values are in `design-tokens.json` → `responsive`. Recreate with the same fluid approach rather than fixed media-query breakpoints if your target stack supports it.

## Design Tokens
Full values in `design-tokens.json` (colors, type scale, spacing, radii, shadows, animation timings, logo spec, responsive approach, the exact tracking-parameter list).

## Assets
- `brand/snip-mark.svg` — vector logo mark.
- `brand/icons/snip-mark-{size}.png` — rendered PNGs at 16, 32, 48, 64, 128, 180, 256, 512, 1024px for favicons and app icons.
- `brand/snip-wordmark-light.png` / `brand/snip-wordmark-dark.png` — icon + wordmark lockups for README/social use, on the page's light and dark backgrounds.
- Fonts are Google Fonts, loaded via `<link>` in the HTML: **Instrument Serif** (italic, headlines + logo glyph), **DM Mono** (labels/code/URLs/wordmark), **DM Sans** (body/UI, weights 300/400/500). The exported PNG assets fall back to Georgia italic for the logo glyph — see the note in `design-tokens.json` → `logo`.

## Files
- `snip landing page.dc.html` — the full design reference (structure + inline styles + animation logic in one file). Now includes real `<link rel="icon">` / `apple-touch-icon"` tags pointing at the bundled brand PNGs.
- `screenshots/hero-idle.png` — hero section with the icon+wordmark lockup in the nav, demo card mid-loop.
- `screenshots/try-it-cleaned.png` — dark "Try it" section with a real URL pasted, showing the cleaned result, copy button, and stripped-param chips.
- `screenshots/what-gets-stripped.png` — full parameter chip grid section.
- `screenshots/how-it-works-and-cta.png` — 3-step section plus bottom CTA and footer.
- `brand/` — logo source + exported assets (see Assets above).
